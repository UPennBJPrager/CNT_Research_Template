from enigmatoolbox._version import __version__

# Default rendering
OFF_SCREEN = False
