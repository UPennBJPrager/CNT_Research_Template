import os
import pandas as PD

def check_ieeg_data(infile,data_pointer_loc=os.getenv("cnt_repo_path")+'/data_pointers/ieeg/cached_ieeg_data.csv'):
    """
    Determines if the user requested ieeg file already exists in Lief.

    Parameters
    ----------
    infile : STR
        User provided identifier of the file to be downloaded.
    data_pointer_loc : STR, optional
        Absolute or relative path to data pointers. The default is $cnt_repo_path+'/data_pointers/ieeg/cached_ieeg_data.csv'):.

    Returns
    -------
    Boolean flag.

    """
    
    pointer_DF = PD.read_csv(data_pointer_loc)
    filelist   = pointer_DF['filepath'].values
    
    if infile in filelist:
        return True
    else:
        return False